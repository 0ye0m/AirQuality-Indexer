# Changelog

Changes to adapters will be documented in this file.

## 02/14/2024
### Removed deprecated adapters
- agaar_mn.js
- airnow-ftp.js
- eea.js
## 02/13/2024
### Removed unused files
- docker-compose.yml
- index.adapter.sh
- index.sh
- accra.js
- arpae-locations.js
- arpae-parameters.js
- arpalazio.js
- defra-locations.js
- israel.js
- moscow-locations.js
- ards-bay.js

## 11/26/2023
### Removed eslint
- Removed eslint from package.json
- Removed .eslintrc

## 11/22/2023
### Set active: false
- south-australia-epa (needs fix, url won't resolve)

## 11/01/2023
### DELETED
- au_sa.js (replaced by southaustralia.js)

## 10/31/2023
### Set active: true
- Mexico Sinaica (Added to deployments)
- Trinidad & Tobago ( needs fix )

## 10/29/2023
### Set active: false
- Mexico Sinaica
- Turkiye (Down)
- Rwanda (Needs work, down?)
  
## 08/23/2023
### Set active: false
- all China stateair adapters (stateair.net not resolving)
- Brazil CETESB (needs environment variables)
- south-australia-epa (needs environment variables)
- Australia - Victoria (needs environment variables)
- Australia - New South Wales (needs environment variables)
- Trinidad & Tobago ( needs fix )

## 07/13/2023
### Removed
- src/adapters/moscow.js
- iconv module

## 07/13/2023
### Removed
- src/adapters/andalucia.js
- src/adapters/anhui.js
- src/adapters/arpae.js
- src/adapters/bogota.js
- src/adapters/caaqm.js
- src/adapters/chinaaqidata.js
- src/adapters/cpcb.js
- src/adapters/data_gov_in.js
- src/adapters/fhmzbih.js
- src/adapters/fhmzbih2.js
- src/adapters/peruclima.js
- src/adapters/poland.js
- src/adapters/quito.js
- src/adapters/taiwan.js
- src/adapters/turkey.js