# Documentation


This is just an `index` page.

## How to start

See the ["Dev quick start guide"](./dev-quick-start.md), there you'll find all the information needed for getting openaq-fetch up an running in your local environment.

## Adapters and sources

The following docs will allow you:

* [Source definition](./source.md) - how to add and specify source.
* [Adapter definition](./adapter.md) - how to write an adapter and what data structures it should provide.
