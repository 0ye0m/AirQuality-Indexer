'use strict';

// only ES5 is allowed in this file
//require('@babel/register')();

// other babel configuration, if necessary

// load the server
require('./fetch');
